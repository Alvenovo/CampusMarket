package com.example.campusmarket;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GoodsAdapter extends RecyclerView.Adapter<GoodsAdapter.ViewHolder> {

    ArrayList<Goods> goodsList;

    public GoodsAdapter(ArrayList<Goods> goodsList) {
        this.goodsList = goodsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_goods, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Goods goods = goodsList.get(position);

        holder.tvTitle.setText(goods.getTitle());
        holder.tvPrice.setText("￥" + goods.getPrice());

        holder.itemView.setOnClickListener(v -> {

            Intent intent =
                    new Intent(v.getContext(),
                            DetailActivity.class);

            intent.putExtra("title", goods.getTitle());
            intent.putExtra("price", goods.getPrice());
            intent.putExtra("description", goods.getDescription());

            v.getContext().startActivity(intent);

        });

        holder.itemView.setOnLongClickListener(v -> {

            new AlertDialog.Builder(v.getContext())
                    .setTitle("删除商品")
                    .setMessage("确定删除该商品吗？")

                    .setPositiveButton("确定", (dialog, which) -> {

                        DBHelper dbHelper =
                                new DBHelper(v.getContext());

                        SQLiteDatabase db =
                                dbHelper.getWritableDatabase();

                        db.delete(
                                "goods",
                                "id=?",
                                new String[]{
                                        String.valueOf(goods.getId())
                                });

                        goodsList.remove(position);

                        notifyDataSetChanged();

                    })

                    .setNegativeButton("取消", null)

                    .show();

            return true;
        });
    }

    @Override
    public int getItemCount() {
        return goodsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvTitle, tvPrice;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvPrice = itemView.findViewById(R.id.tvPrice);
        }
    }
}