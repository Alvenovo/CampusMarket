package com.example.campusmarket;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    Button btnPublish, btnMine;

    EditText etSearch;

    ArrayList<Goods> goodsList;

    GoodsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        btnPublish = findViewById(R.id.btnPublish);
        btnMine = findViewById(R.id.btnMine);

        etSearch = findViewById(R.id.etSearch);

        goodsList = new ArrayList<>();

        adapter = new GoodsAdapter(goodsList);

        recyclerView.setLayoutManager(
                new LinearLayoutManager(this));

        recyclerView.setAdapter(adapter);

        loadGoods("");

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s,
                                          int start,
                                          int count,
                                          int after) {

            }

            @Override
            public void onTextChanged(CharSequence s,
                                      int start,
                                      int before,
                                      int count) {

                loadGoods(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnPublish.setOnClickListener(v -> {

            Intent intent =
                    new Intent(MainActivity.this,
                            PublishActivity.class);

            startActivity(intent);

        });

        btnMine.setOnClickListener(v -> {

            Intent intent =
                    new Intent(MainActivity.this,
                            MineActivity.class);

            startActivity(intent);

        });
    }

    private void loadGoods(String keyword) {

        goodsList.clear();

        DBHelper dbHelper = new DBHelper(this);

        SQLiteDatabase db =
                dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "select * from goods where title like ?",
                new String[]{
                        "%" + keyword + "%"
                });

        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow("id"));

            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("title"));

            String price =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("price"));

            String description =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("description"));

            goodsList.add(
                    new Goods(
                            id,
                            title,
                            price,
                            description
                    ));
        }

        cursor.close();

        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadGoods(etSearch.getText().toString());
    }
}