package com.example.campusmarket;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etUser, etPwd;
    Button btnLogin, btnRegister;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUser = findViewById(R.id.etUser);
        etPwd = findViewById(R.id.etPwd);

        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);

        dbHelper = new DBHelper(this);

        SharedPreferences sp =
                getSharedPreferences("user", MODE_PRIVATE);

        String savedUser = sp.getString("username", "");

        etUser.setText(savedUser);

        btnLogin.setOnClickListener(v -> {

            String user = etUser.getText().toString();
            String pwd = etPwd.getText().toString();

            SQLiteDatabase db =
                    dbHelper.getReadableDatabase();

            Cursor cursor = db.rawQuery(
                    "select * from user where username=? and password=?",
                    new String[]{user, pwd});

            if (cursor.moveToFirst()) {

                sp.edit().putString("username", user).apply();

                Toast.makeText(this,
                        "登录成功",
                        Toast.LENGTH_SHORT).show();

                Intent intent =
                        new Intent(LoginActivity.this,
                                MainActivity.class);

                startActivity(intent);

            } else {

                Toast.makeText(this,
                        "账号或密码错误",
                        Toast.LENGTH_SHORT).show();
            }

            cursor.close();
        });

        btnRegister.setOnClickListener(v -> {

            Intent intent =
                    new Intent(LoginActivity.this,
                            RegisterActivity.class);

            startActivity(intent);

        });
    }
}