package com.example.campusmarket;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MineActivity extends AppCompatActivity {

    TextView tvUser;

    Button btnLogout, btnFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine);

        tvUser = findViewById(R.id.tvUser);

        btnLogout = findViewById(R.id.btnLogout);

        btnFavorite = findViewById(R.id.btnFavorite);

        SharedPreferences sp =
                getSharedPreferences("user", MODE_PRIVATE);

        String username =
                sp.getString("username", "未登录");

        tvUser.setText("当前用户：" + username);

        btnFavorite.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MineActivity.this,
                            FavoriteActivity.class);

            startActivity(intent);

        });

        btnLogout.setOnClickListener(v -> {

            sp.edit().clear().apply();

            Intent intent =
                    new Intent(
                            MineActivity.this,
                            LoginActivity.class);

            startActivity(intent);

            finish();

        });
    }
}