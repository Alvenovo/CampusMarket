package com.example.campusmarket;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class FavoriteActivity extends AppCompatActivity {

    ListView listView;

    ArrayList<String> favoriteList;

    ArrayList<Integer> idList;

    ArrayAdapter<String> adapter;

    DBHelper dbHelper;

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        listView = findViewById(R.id.listView);

        favoriteList = new ArrayList<>();

        idList = new ArrayList<>();

        dbHelper = new DBHelper(this);

        db = dbHelper.getWritableDatabase();

        loadData();

        listView.setOnItemLongClickListener((parent, view, position, id) -> {

            new AlertDialog.Builder(this)
                    .setTitle("删除收藏")
                    .setMessage("确定删除该收藏吗？")

                    .setPositiveButton("确定", (dialog, which) -> {

                        int favoriteId = idList.get(position);

                        db.delete(
                                "favorite",
                                "id=?",
                                new String[]{
                                        String.valueOf(favoriteId)
                                });

                        loadData();

                    })

                    .setNegativeButton("取消", null)

                    .show();

            return true;
        });
    }

    private void loadData() {

        favoriteList.clear();

        idList.clear();

        Cursor cursor = db.rawQuery(
                "select * from favorite",
                null);

        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow("id"));

            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("title"));

            String price =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("price"));

            idList.add(id);

            favoriteList.add(
                    title + "    ￥" + price);
        }

        cursor.close();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                favoriteList);

        listView.setAdapter(adapter);
    }
}