package com.example.campusmarket;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PublishActivity extends AppCompatActivity {

    EditText etTitle, etPrice, etDesc;

    Button btnPublish;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish);

        etTitle = findViewById(R.id.etTitle);
        etPrice = findViewById(R.id.etPrice);
        etDesc = findViewById(R.id.etDesc);

        btnPublish = findViewById(R.id.btnPublish);

        dbHelper = new DBHelper(this);

        btnPublish.setOnClickListener(v -> {

            String title = etTitle.getText().toString();
            String price = etPrice.getText().toString();
            String desc = etDesc.getText().toString();

            if(title.isEmpty() || price.isEmpty()){

                Toast.makeText(this,
                        "请填写完整信息",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            SQLiteDatabase db =
                    dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();

            values.put("title", title);
            values.put("price", price);
            values.put("description", desc);

            db.insert("goods", null, values);

            Toast.makeText(this,
                    "发布成功",
                    Toast.LENGTH_SHORT).show();

            finish();

        });
    }
}