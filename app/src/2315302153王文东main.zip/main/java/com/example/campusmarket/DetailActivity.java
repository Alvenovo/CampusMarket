package com.example.campusmarket;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    TextView tvTitle, tvPrice, tvDesc;

    Button btnFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvTitle = findViewById(R.id.tvTitle);

        tvPrice = findViewById(R.id.tvPrice);

        tvDesc = findViewById(R.id.tvDesc);

        btnFavorite = findViewById(R.id.btnFavorite);

        String title =
                getIntent().getStringExtra("title");

        String price =
                getIntent().getStringExtra("price");

        String desc =
                getIntent().getStringExtra("description");

        tvTitle.setText(title);

        tvPrice.setText("￥" + price);

        tvDesc.setText(desc);

        btnFavorite.setOnClickListener(v -> {

            DBHelper dbHelper =
                    new DBHelper(this);

            SQLiteDatabase db =
                    dbHelper.getWritableDatabase();

            ContentValues values =
                    new ContentValues();

            values.put("title", title);

            values.put("price", price);

            long result = db.insert(
                    "favorite",
                    null,
                    values);

            if (result != -1) {

                Toast.makeText(
                        this,
                        "收藏成功",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "收藏失败",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}