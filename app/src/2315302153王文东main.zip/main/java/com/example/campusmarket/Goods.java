package com.example.campusmarket;

public class Goods {

    private int id;

    private String title;
    private String price;
    private String description;

    public Goods(int id, String title, String price, String description) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }
}