package com.example.campusmarket;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText etUser, etPwd;
    Button btnRegister;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUser = findViewById(R.id.etUser);
        etPwd = findViewById(R.id.etPwd);
        btnRegister = findViewById(R.id.btnRegister);

        dbHelper = new DBHelper(this);

        btnRegister.setOnClickListener(v -> {

            String user = etUser.getText().toString();
            String pwd = etPwd.getText().toString();

            if(user.isEmpty() || pwd.isEmpty()){

                Toast.makeText(this,
                        "请输入完整信息",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            SQLiteDatabase db =
                    dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();

            values.put("username", user);
            values.put("password", pwd);

            db.insert("user", null, values);

            Toast.makeText(this,
                    "注册成功",
                    Toast.LENGTH_SHORT).show();

            finish();

        });
    }
}