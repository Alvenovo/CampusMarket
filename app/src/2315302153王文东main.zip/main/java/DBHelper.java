package com.example.campusmarket;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "market.db";

    // 数据库版本升级
    public static final int DB_VERSION = 2;

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "create table goods(" +
                        "id integer primary key autoincrement," +
                        "title text," +
                        "price text," +
                        "description text" +
                        ")");

        db.execSQL(
                "create table favorite(" +
                        "id integer primary key autoincrement," +
                        "title text," +
                        "price text" +
                        ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {

        // 如果旧版本没有 favorite 表
        // 就创建它

        db.execSQL(
                "create table if not exists favorite(" +
                        "id integer primary key autoincrement," +
                        "title text," +
                        "price text" +
                        ")");
    }
}